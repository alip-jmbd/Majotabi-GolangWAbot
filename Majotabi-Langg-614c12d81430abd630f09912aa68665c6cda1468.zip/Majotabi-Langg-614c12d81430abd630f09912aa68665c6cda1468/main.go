package main

import (
	"context"
	"fmt"
	"majotabi-bot/feature/ai"
	"majotabi-bot/lib/config"
	"majotabi-bot/lib/database"
	"majotabi-bot/lib/helper"
	"majotabi-bot/lib/registry"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	_ "majotabi-bot/feature/main"
	_ "majotabi-bot/feature/owner"

	"github.com/mdp/qrterminal/v3"
	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
)

func main() {
	if err := config.LoadConfig(); err != nil {
		panic(fmt.Sprintf("Gagal load config: %v", err))
	}

	if err := database.Connect(); err != nil {
		panic(fmt.Sprintf("Gagal connect database: %v", err))
	}

	clientLog := waLog.Stdout("Client", "ERROR", true)
	deviceStore, err := database.Container.GetFirstDevice(context.Background())
	if err != nil {
		panic(err)
	}

	client := whatsmeow.NewClient(deviceStore, clientLog)
	client.AddEventHandler(func(evt interface{}) {
		EventHandler(client, evt)
	})

	if client.Store.ID == nil {
		fmt.Println("\n===========================================")
		fmt.Println("   MAJOTABI BOT - SETUP LOGIN")
		fmt.Println("===========================================")
		fmt.Println("1. QR Code")
		fmt.Println("2. Pairing Code (Rekomendasi)")
		fmt.Print("Pilih (1/2): ")
		
		var choice int
		_, err := fmt.Scanln(&choice)
		if err != nil {
			choice = 2
		}

		if choice == 2 {
			err = client.Connect()
			if err != nil {
				panic(fmt.Sprintf("Gagal connect: %v", err))
			}
			
			fmt.Println(">> Menunggu kestabilan koneksi (5 detik)...")
			time.Sleep(5 * time.Second)

			fmt.Print("\nMasukkan Nomor HP (Format: 628xxx): ")
			var phone string
			fmt.Scanln(&phone)
			phone = strings.TrimSpace(phone)

			fmt.Println(">> Meminta Pairing Code...")
			code, err := client.PairPhone(context.Background(), phone, true, whatsmeow.PairClientChrome, "Chrome (Linux)")
			if err != nil {
				fmt.Printf("\nERROR: %v\n", err)
				os.Exit(1)
			}
			
			fmt.Println("\n===========================================")
			fmt.Printf(" KODE PAIRING:  %s \n", code)
			fmt.Println("===========================================")
		} else {
			qrChan, _ := client.GetQRChannel(context.Background())
			err = client.Connect()
			if err != nil {
				panic(err)
			}
			for evt := range qrChan {
				if evt.Event == "code" {
					qrterminal.GenerateHalfBlock(evt.Code, qrterminal.L, os.Stdout)
				} else {
					fmt.Println("QR Event:", evt.Event)
				}
			}
		}
	} else {
		err = client.Connect()
		if err != nil {
			panic(err)
		}
	}

	fmt.Printf("\nBot %s Berjalan!\nOwner: %s / %s\n", config.Current.BotName, config.Current.OwnerNumber, config.Current.OwnerLID)
	
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	<-c

	client.Disconnect()
	database.Container.Close()
	fmt.Println("Bot Berhenti.")
}

func EventHandler(client *whatsmeow.Client, evt interface{}) {
	switch v := evt.(type) {
	case *events.Message:
		msg := v.Message
		if msg == nil {
			return
		}
		
		txt := ""
		if msg.Conversation != nil {
			txt = *msg.Conversation
		} else if msg.ExtendedTextMessage != nil {
			txt = *msg.ExtendedTextMessage.Text
		} else if msg.ImageMessage != nil && msg.ImageMessage.Caption != nil {
			txt = *msg.ImageMessage.Caption
		}

		senderJID := v.Info.Sender
		senderUser := senderJID.User
		
		isOwner := senderUser == config.Current.OwnerNumber || senderUser == config.Current.OwnerLID
		
		isMentioned := false
		if extMsg := msg.GetExtendedTextMessage(); extMsg != nil && extMsg.ContextInfo != nil {
			for _, mentionedJIDString := range extMsg.ContextInfo.MentionedJID {
				if client.Store.ID != nil && mentionedJIDString == client.Store.ID.String() {
					isMentioned = true
					break
				}
			}
		}

		isReplyToBot := false
		if extMsg := msg.GetExtendedTextMessage(); extMsg != nil && extMsg.ContextInfo != nil {
			if extMsg.ContextInfo.GetParticipant() == client.Store.ID.String() {
				isReplyToBot = true
			}
		}

		if config.IsElainaActive && (strings.Contains(strings.ToLower(txt), "elaina") || isMentioned || isReplyToBot) {
			var imageData []byte
			var err error
			if msg.ImageMessage != nil {
				imageData, err = client.Download(context.Background(), msg.ImageMessage)
				if err != nil {
					fmt.Println("Gagal download gambar:", err)
				}
			}
			
			go func() {
				client.SendChatPresence(context.Background(), senderJID, types.ChatPresenceComposing, types.ChatPresenceMediaText)
				defer client.SendChatPresence(context.Background(), senderJID, types.ChatPresencePaused, types.ChatPresenceMediaText)

				response, err := ai.GenerateResponse(context.Background(), senderJID.String(), txt, imageData)
				if err != nil {
					fmt.Println("Error dari AI:", err)
					response = "Hmph, sepertinya aku sedang tidak mood bicara."
				}
				
				client.SendMessage(context.Background(), v.Info.Chat, &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text:        &response,
						ContextInfo: helper.GetContext(v),
					},
				})
			}()
			return
		}

		if !config.IsPublic && !isOwner {
			return
		}

		tag := "[USER]"
		if isOwner {
			tag = "[OWNER]"
		}

		chatType := "PC"
		if v.Info.IsGroup {
			chatType = "GC"
		}
		
		timestamp := v.Info.Timestamp.Format("15:04:05")
		if txt != "" {
			fmt.Printf("[%s] [%s] %s %s: %s\n", timestamp, chatType, tag, senderUser, txt)
		}

		if strings.HasPrefix(txt, config.Current.Prefix) {
			args := strings.Split(txt, " ")
			cmd := strings.TrimPrefix(args[0], config.Current.Prefix)
			
			if (cmd == "self" || cmd == "public" || cmd == "elaina") && !isOwner {
				return
			}
			
			if handler, ok := registry.GetHandler(cmd); ok {
				go handler(context.Background(), client, v)
			}
		}
	}
}
